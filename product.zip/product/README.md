# README

Instuktion til launch:

npm i

npm start

åben på localhost:3000

Have a gouda time :D